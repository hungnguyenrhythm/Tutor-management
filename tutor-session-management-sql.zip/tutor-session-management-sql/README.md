# Tutor Session Management System (SQL Version)

A full-stack MVP for a tutor session management system using:

- Frontend: React + Vite
- Backend: Node.js + Express
- Database: MySQL via Sequelize ORM
- Auth: JWT + bcrypt

## Features

- Register/login as Student or Tutor
- Tutors can manage profile, subject mastery, availability, and see today's sessions
- Students can search tutors and book sessions
- Students can view their booked sessions

## Backend setup

```bash
cd server
npm install
```

Create the database:

```sql
CREATE DATABASE tutor_app_sql;
```

Create `.env` from `.env.example`, then run:

```bash
npm run dev
```

## Frontend setup

```bash
cd client
npm install
npm run dev
```
