import { Link, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './state/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import StudentDashboard from './pages/StudentDashboard';
import TutorDashboard from './pages/TutorDashboard';
import TutorSearchPage from './pages/TutorSearchPage';

function ProtectedRoute({ children, roles }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { user, logout } = useAuth();

  return (
    <div className="container">
      <header className="topbar">
        <h1>Tutor Session Management (SQL)</h1>
        <nav>
          <Link to="/">Home</Link>
          {!user && <Link to="/login">Login</Link>}
          {!user && <Link to="/register">Register</Link>}
          {user?.role === 'student' && <Link to="/search">Search Tutors</Link>}
          {user?.role === 'student' && <Link to="/student">Student Dashboard</Link>}
          {user?.role === 'tutor' && <Link to="/tutor">Tutor Dashboard</Link>}
          {user && <button onClick={logout}>Logout</button>}
        </nav>
      </header>

      <Routes>
        <Route path="/" element={<div className="card"><h2>Welcome</h2><p>Students can search and book tutor sessions. Tutors can manage expertise, availability, and daily schedules.</p></div>} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/search" element={<ProtectedRoute roles={['student']}><TutorSearchPage /></ProtectedRoute>} />
        <Route path="/student" element={<ProtectedRoute roles={['student']}><StudentDashboard /></ProtectedRoute>} />
        <Route path="/tutor" element={<ProtectedRoute roles={['tutor']}><TutorDashboard /></ProtectedRoute>} />
      </Routes>
    </div>
  );
}
