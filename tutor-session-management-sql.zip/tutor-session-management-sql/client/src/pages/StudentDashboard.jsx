import { useEffect, useState } from 'react';
import api from '../api';

export default function StudentDashboard() {
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    api.get('/students/me/sessions').then(({ data }) => setSessions(data)).catch(() => {});
  }, []);

  return (
    <div className="card">
      <h2>My Sessions</h2>
      {sessions.length === 0 ? <p>No sessions booked yet.</p> : (
        <ul className="list">
          {sessions.map((session) => (
            <li key={session.id}>
              <strong>{session.subject?.name}</strong> with {session.tutor?.name}<br />
              {new Date(session.startDateTime).toLocaleString()} - {new Date(session.endDateTime).toLocaleString()}<br />
              Status: {session.status}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
