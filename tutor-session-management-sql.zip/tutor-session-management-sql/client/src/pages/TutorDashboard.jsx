import { useEffect, useState } from 'react';
import api from '../api';

const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const masteryLevels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];

export default function TutorDashboard() {
  const [profile, setProfile] = useState(null);
  const [dailySessions, setDailySessions] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [profileForm, setProfileForm] = useState({ bio: '', timezone: 'America/New_York', isActive: true });
  const [subjectForm, setSubjectForm] = useState({ subjectId: '', masteryLevel: 'Intermediate', yearsExperience: 1 });
  const [availabilityForm, setAvailabilityForm] = useState({ dayOfWeek: 'Monday', startTime: '09:00', endTime: '10:00' });

  async function loadData() {
    const [profileRes, sessionsRes, subjectsRes] = await Promise.all([
      api.get('/tutors/me/profile'),
      api.get('/tutors/me/daily-sessions'),
      api.get('/subjects')
    ]);
    setProfile(profileRes.data);
    setDailySessions(sessionsRes.data);
    setSubjects(subjectsRes.data);
    setProfileForm({
      bio: profileRes.data.bio || '',
      timezone: profileRes.data.timezone || 'America/New_York',
      isActive: profileRes.data.isActive
    });
  }

  useEffect(() => { loadData().catch(() => {}); }, []);

  async function seedSubjects() {
    await api.post('/subjects/seed');
    const { data } = await api.get('/subjects');
    setSubjects(data);
  }

  async function updateProfile(e) {
    e.preventDefault();
    await api.put('/tutors/me/profile', profileForm);
    await loadData();
  }

  async function addSubject(e) {
    e.preventDefault();
    await api.post('/tutors/me/subjects', { ...subjectForm, subjectId: Number(subjectForm.subjectId), yearsExperience: Number(subjectForm.yearsExperience) });
    setSubjectForm({ subjectId: '', masteryLevel: 'Intermediate', yearsExperience: 1 });
    await loadData();
  }

  async function addAvailability(e) {
    e.preventDefault();
    await api.post('/tutors/me/availability', availabilityForm);
    await loadData();
  }

  async function removeSubject(id) {
    await api.delete(`/tutors/me/subjects/${id}`);
    await loadData();
  }

  async function removeAvailability(id) {
    await api.delete(`/tutors/me/availability/${id}`);
    await loadData();
  }

  return (
    <div className="grid">
      <div className="card">
        <h2>Tutor Profile</h2>
        <button onClick={seedSubjects}>Seed Default Subjects</button>
        <form onSubmit={updateProfile} className="stack">
          <textarea placeholder="Bio" value={profileForm.bio} onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })} />
          <input placeholder="Timezone" value={profileForm.timezone} onChange={(e) => setProfileForm({ ...profileForm, timezone: e.target.value })} />
          <label><input type="checkbox" checked={profileForm.isActive} onChange={(e) => setProfileForm({ ...profileForm, isActive: e.target.checked })} /> Active</label>
          <button type="submit">Save Profile</button>
        </form>
      </div>

      <div className="card">
        <h2>Subjects & Mastery</h2>
        <form onSubmit={addSubject} className="stack">
          <select value={subjectForm.subjectId} onChange={(e) => setSubjectForm({ ...subjectForm, subjectId: e.target.value })}>
            <option value="">Select subject</option>
            {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
          </select>
          <select value={subjectForm.masteryLevel} onChange={(e) => setSubjectForm({ ...subjectForm, masteryLevel: e.target.value })}>
            {masteryLevels.map((level) => <option key={level} value={level}>{level}</option>)}
          </select>
          <input type="number" min="0" value={subjectForm.yearsExperience} onChange={(e) => setSubjectForm({ ...subjectForm, yearsExperience: e.target.value })} />
          <button type="submit">Add Subject</button>
        </form>
        <ul className="list">
          {profile?.subjects?.map((item) => (
            <li key={item.id}>
              {item.subject?.name} - {item.masteryLevel} ({item.yearsExperience} yrs)
              <button onClick={() => removeSubject(item.id)}>Remove</button>
            </li>
          ))}
        </ul>
      </div>

      <div className="card">
        <h2>Availability</h2>
        <form onSubmit={addAvailability} className="stack">
          <select value={availabilityForm.dayOfWeek} onChange={(e) => setAvailabilityForm({ ...availabilityForm, dayOfWeek: e.target.value })}>
            {days.map((day) => <option key={day} value={day}>{day}</option>)}
          </select>
          <input type="time" value={availabilityForm.startTime} onChange={(e) => setAvailabilityForm({ ...availabilityForm, startTime: e.target.value })} />
          <input type="time" value={availabilityForm.endTime} onChange={(e) => setAvailabilityForm({ ...availabilityForm, endTime: e.target.value })} />
          <button type="submit">Add Availability</button>
        </form>
        <ul className="list">
          {profile?.availability?.map((slot) => (
            <li key={slot.id}>
              {slot.dayOfWeek} {slot.startTime} - {slot.endTime}
              <button onClick={() => removeAvailability(slot.id)}>Remove</button>
            </li>
          ))}
        </ul>
      </div>

      <div className="card">
        <h2>Today's Sessions</h2>
        {dailySessions.length === 0 ? <p>No sessions today.</p> : (
          <ul className="list">
            {dailySessions.map((session) => (
              <li key={session.id}>
                {session.subject?.name} with {session.student?.name}<br />
                {new Date(session.startDateTime).toLocaleString()}<br />
                Status: {session.status}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
