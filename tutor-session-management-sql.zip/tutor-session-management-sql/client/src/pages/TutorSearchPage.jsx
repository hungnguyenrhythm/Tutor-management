import { useEffect, useState } from 'react';
import api from '../api';

const masteryLevels = ['', 'Beginner', 'Intermediate', 'Advanced', 'Expert'];
const days = ['', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function TutorSearchPage() {
  const [filters, setFilters] = useState({ subject: '', masteryLevel: '', dayOfWeek: '' });
  const [results, setResults] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [booking, setBooking] = useState({ tutorUserId: '', subjectId: '', startDateTime: '', endDateTime: '', notes: '' });
  const [message, setMessage] = useState('');

  useEffect(() => { api.get('/subjects').then(({ data }) => setSubjects(data)).catch(() => {}); }, []);

  async function searchTutors(e) {
    if (e) e.preventDefault();
    const { data } = await api.get('/tutors/search', { params: filters });
    setResults(data);
  }

  async function bookSession(e) {
    e.preventDefault();
    setMessage('');
    try {
      await api.post('/sessions', booking);
      setMessage('Session booked successfully');
      setBooking({ tutorUserId: '', subjectId: '', startDateTime: '', endDateTime: '', notes: '' });
    } catch (error) {
      setMessage(error.response?.data?.message || 'Booking failed');
    }
  }

  return (
    <div className="grid">
      <div className="card">
        <h2>Search Tutors</h2>
        <form onSubmit={searchTutors} className="stack">
          <input placeholder="Subject name" value={filters.subject} onChange={(e) => setFilters({ ...filters, subject: e.target.value })} />
          <select value={filters.masteryLevel} onChange={(e) => setFilters({ ...filters, masteryLevel: e.target.value })}>
            {masteryLevels.map((level) => <option key={level} value={level}>{level || 'Any mastery'}</option>)}
          </select>
          <select value={filters.dayOfWeek} onChange={(e) => setFilters({ ...filters, dayOfWeek: e.target.value })}>
            {days.map((day) => <option key={day} value={day}>{day || 'Any day'}</option>)}
          </select>
          <button type="submit">Search</button>
        </form>

        <ul className="list">
          {results.map((tutor) => (
            <li key={tutor.id}>
              <strong>{tutor.user?.name}</strong><br />
              {tutor.bio}<br />
              Subjects: {tutor.subjects?.map((s) => `${s.subject?.name} (${s.masteryLevel})`).join(', ')}<br />
              Availability: {tutor.availability?.map((a) => `${a.dayOfWeek} ${a.startTime}-${a.endTime}`).join(', ')}<br />
              <button onClick={() => setBooking({ ...booking, tutorUserId: tutor.user?.id })}>Select Tutor</button>
            </li>
          ))}
        </ul>
      </div>

      <div className="card">
        <h2>Book Session</h2>
        <form onSubmit={bookSession} className="stack">
          <input placeholder="Tutor user ID" value={booking.tutorUserId} onChange={(e) => setBooking({ ...booking, tutorUserId: e.target.value })} />
          <select value={booking.subjectId} onChange={(e) => setBooking({ ...booking, subjectId: Number(e.target.value) })}>
            <option value="">Select subject</option>
            {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
          </select>
          <input type="datetime-local" value={booking.startDateTime} onChange={(e) => setBooking({ ...booking, startDateTime: e.target.value })} />
          <input type="datetime-local" value={booking.endDateTime} onChange={(e) => setBooking({ ...booking, endDateTime: e.target.value })} />
          <textarea placeholder="Notes" value={booking.notes} onChange={(e) => setBooking({ ...booking, notes: e.target.value })} />
          <button type="submit">Book Session</button>
        </form>
        {message && <p>{message}</p>}
      </div>
    </div>
  );
}
