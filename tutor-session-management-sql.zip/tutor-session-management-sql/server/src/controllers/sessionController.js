const { Op } = require('sequelize');
const { Session, Subject, User } = require('../models');

exports.createSession = async (req, res) => {
  try {
    const { tutorUserId, subjectId, startDateTime, endDateTime, notes } = req.body;
    if (!tutorUserId || !subjectId || !startDateTime || !endDateTime) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const start = new Date(startDateTime);
    const end = new Date(endDateTime);
    if (start >= end) return res.status(400).json({ message: 'Start time must be before end time' });

    const overlapping = await Session.findOne({
      where: {
        tutorUserId,
        status: 'scheduled',
        startDateTime: { [Op.lt]: end },
        endDateTime: { [Op.gt]: start }
      }
    });
    if (overlapping) return res.status(400).json({ message: 'Tutor already has a session in that time range' });

    const session = await Session.create({ studentId: req.user.id, tutorUserId, subjectId, startDateTime: start, endDateTime: end, notes });
    const fullSession = await Session.findByPk(session.id, {
      include: [
        { model: User, as: 'student', attributes: ['id','name','email'] },
        { model: User, as: 'tutor', attributes: ['id','name','email'] },
        { model: Subject, as: 'subject', attributes: ['id','name'] }
      ]
    });
    res.status(201).json(fullSession);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create session', error: error.message });
  }
};

exports.getTutorSessions = async (req, res) => {
  try {
    const sessions = await Session.findAll({
      where: { tutorUserId: req.user.id },
      include: [
        { model: User, as: 'student', attributes: ['id','name','email'] },
        { model: Subject, as: 'subject', attributes: ['id','name'] }
      ],
      order: [['startDateTime','ASC']]
    });
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load tutor sessions', error: error.message });
  }
};

exports.updateSessionStatus = async (req, res) => {
  try {
    const { status, notes } = req.body;
    const session = await Session.findByPk(req.params.id);
    if (!session) return res.status(404).json({ message: 'Session not found' });

    const allowedUser = req.user.id === session.studentId || req.user.id === session.tutorUserId;
    if (!allowedUser) return res.status(403).json({ message: 'Forbidden' });

    await session.update({ status: status ?? session.status, notes: notes ?? session.notes });
    res.json(session);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update session', error: error.message });
  }
};
