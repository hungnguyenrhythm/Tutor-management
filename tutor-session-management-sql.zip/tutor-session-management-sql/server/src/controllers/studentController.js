const { Session, Subject, User } = require('../models');

exports.getStudentSessions = async (req, res) => {
  try {
    const sessions = await Session.findAll({
      where: { studentId: req.user.id },
      include: [
        { model: User, as: 'tutor', attributes: ['id','name','email'] },
        { model: Subject, as: 'subject', attributes: ['id','name'] }
      ],
      order: [['startDateTime','ASC']]
    });
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load student sessions', error: error.message });
  }
};
