const { Subject } = require('../models');

exports.getSubjects = async (req, res) => {
  try {
    const subjects = await Subject.findAll({ order: [['name', 'ASC']] });
    res.json(subjects);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load subjects', error: error.message });
  }
};

exports.createSubject = async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ message: 'Subject name is required' });
    const subject = await Subject.create({ name });
    res.status(201).json(subject);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create subject', error: error.message });
  }
};

exports.seedDefaultSubjects = async (req, res) => {
  try {
    const names = ['Mathematics','Physics','Chemistry','Biology','Computer Science','JavaScript','Java','Python','English','History'];
    for (const name of names) await Subject.findOrCreate({ where: { name } });
    const subjects = await Subject.findAll({ order: [['name', 'ASC']] });
    res.json(subjects);
  } catch (error) {
    res.status(500).json({ message: 'Failed to seed subjects', error: error.message });
  }
};
