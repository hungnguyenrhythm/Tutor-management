const { Op } = require('sequelize');
const { User, TutorProfile, TutorSubject, Subject, Availability, Session } = require('../models');

exports.getTutorProfile = async (req, res) => {
  try {
    const tutorProfile = await TutorProfile.findOne({
      where: { userId: req.user.id },
      include: [
        { model: User, as: 'user', attributes: ['id','name','email','role'] },
        { model: TutorSubject, as: 'subjects', include: [{ model: Subject, as: 'subject' }] },
        { model: Availability, as: 'availability' }
      ]
    });
    if (!tutorProfile) return res.status(404).json({ message: 'Tutor profile not found' });
    res.json(tutorProfile);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load tutor profile', error: error.message });
  }
};

exports.updateTutorProfile = async (req, res) => {
  try {
    const { bio, timezone, isActive } = req.body;
    const tutorProfile = await TutorProfile.findOne({ where: { userId: req.user.id } });
    if (!tutorProfile) return res.status(404).json({ message: 'Tutor profile not found' });
    await tutorProfile.update({
      bio: bio ?? tutorProfile.bio,
      timezone: timezone ?? tutorProfile.timezone,
      isActive: typeof isActive === 'boolean' ? isActive : tutorProfile.isActive
    });
    res.json(tutorProfile);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update profile', error: error.message });
  }
};

exports.addTutorSubject = async (req, res) => {
  try {
    const { subjectId, masteryLevel, yearsExperience } = req.body;
    const tutorProfile = await TutorProfile.findOne({ where: { userId: req.user.id } });
    if (!tutorProfile) return res.status(404).json({ message: 'Tutor profile not found' });

    const record = await TutorSubject.create({ tutorProfileId: tutorProfile.id, subjectId, masteryLevel, yearsExperience });
    const fullRecord = await TutorSubject.findByPk(record.id, { include: [{ model: Subject, as: 'subject' }] });
    res.status(201).json(fullRecord);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add tutor subject', error: error.message });
  }
};

exports.deleteTutorSubject = async (req, res) => {
  try {
    const tutorProfile = await TutorProfile.findOne({ where: { userId: req.user.id } });
    if (!tutorProfile) return res.status(404).json({ message: 'Tutor profile not found' });

    const record = await TutorSubject.findOne({ where: { id: req.params.id, tutorProfileId: tutorProfile.id } });
    if (!record) return res.status(404).json({ message: 'Subject mapping not found' });
    await record.destroy();
    res.json({ message: 'Tutor subject deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete tutor subject', error: error.message });
  }
};

exports.addAvailability = async (req, res) => {
  try {
    const { dayOfWeek, startTime, endTime, isRecurring } = req.body;
    const tutorProfile = await TutorProfile.findOne({ where: { userId: req.user.id } });
    if (!tutorProfile) return res.status(404).json({ message: 'Tutor profile not found' });

    const availability = await Availability.create({ tutorProfileId: tutorProfile.id, dayOfWeek, startTime, endTime, isRecurring: isRecurring ?? true });
    res.status(201).json(availability);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add availability', error: error.message });
  }
};

exports.deleteAvailability = async (req, res) => {
  try {
    const tutorProfile = await TutorProfile.findOne({ where: { userId: req.user.id } });
    if (!tutorProfile) return res.status(404).json({ message: 'Tutor profile not found' });

    const availability = await Availability.findOne({ where: { id: req.params.id, tutorProfileId: tutorProfile.id } });
    if (!availability) return res.status(404).json({ message: 'Availability not found' });

    await availability.destroy();
    res.json({ message: 'Availability deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete availability', error: error.message });
  }
};

exports.searchTutors = async (req, res) => {
  try {
    const { subject, masteryLevel, dayOfWeek } = req.query;
    const subjectWhere = subject ? { name: { [Op.like]: `%${subject}%` } } : {};
    const tutorSubjectWhere = masteryLevel ? { masteryLevel } : {};
    const availabilityWhere = dayOfWeek ? { dayOfWeek } : {};

    const tutors = await TutorProfile.findAll({
      where: { isActive: true },
      include: [
        { model: User, as: 'user', attributes: ['id','name','email'] },
        {
          model: TutorSubject,
          as: 'subjects',
          where: Object.keys(tutorSubjectWhere).length ? tutorSubjectWhere : undefined,
          required: !!(subject || masteryLevel),
          include: [{ model: Subject, as: 'subject', where: Object.keys(subjectWhere).length ? subjectWhere : undefined }]
        },
        {
          model: Availability,
          as: 'availability',
          where: Object.keys(availabilityWhere).length ? availabilityWhere : undefined,
          required: !!dayOfWeek
        }
      ]
    });
    res.json(tutors);
  } catch (error) {
    res.status(500).json({ message: 'Tutor search failed', error: error.message });
  }
};

exports.getTutorDailySessions = async (req, res) => {
  try {
    const date = req.query.date ? new Date(req.query.date) : new Date();
    const start = new Date(date); start.setHours(0,0,0,0);
    const end = new Date(date); end.setHours(23,59,59,999);

    const sessions = await Session.findAll({
      where: { tutorUserId: req.user.id, startDateTime: { [Op.between]: [start, end] } },
      include: [
        { model: User, as: 'student', attributes: ['id','name','email'] },
        { model: Subject, as: 'subject', attributes: ['id','name'] }
      ],
      order: [['startDateTime','ASC']]
    });
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ message: 'Failed to load daily sessions', error: error.message });
  }
};
