const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

module.exports = sequelize.define('Availability', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  tutorProfileId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  dayOfWeek: { type: DataTypes.ENUM('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), allowNull: false },
  startTime: { type: DataTypes.TIME, allowNull: false },
  endTime: { type: DataTypes.TIME, allowNull: false },
  isRecurring: { type: DataTypes.BOOLEAN, defaultValue: true }
});
