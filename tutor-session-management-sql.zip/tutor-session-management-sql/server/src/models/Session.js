const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

module.exports = sequelize.define('Session', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  studentId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  tutorUserId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  subjectId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  startDateTime: { type: DataTypes.DATE, allowNull: false },
  endDateTime: { type: DataTypes.DATE, allowNull: false },
  status: { type: DataTypes.ENUM('scheduled','completed','canceled'), allowNull: false, defaultValue: 'scheduled' },
  notes: { type: DataTypes.TEXT, allowNull: true }
});
