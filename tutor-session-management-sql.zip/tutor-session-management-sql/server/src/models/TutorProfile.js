const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

module.exports = sequelize.define('TutorProfile', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  userId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, unique: true },
  bio: { type: DataTypes.TEXT, allowNull: true },
  timezone: { type: DataTypes.STRING(64), allowNull: true, defaultValue: 'America/New_York' },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
});
