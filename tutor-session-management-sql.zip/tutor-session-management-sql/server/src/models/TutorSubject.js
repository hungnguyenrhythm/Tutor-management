const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

module.exports = sequelize.define('TutorSubject', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  tutorProfileId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  subjectId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false },
  masteryLevel: { type: DataTypes.ENUM('Beginner', 'Intermediate', 'Advanced', 'Expert'), allowNull: false, defaultValue: 'Intermediate' },
  yearsExperience: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false, defaultValue: 1 }
});
