const sequelize = require('../config/db');
const User = require('./User');
const TutorProfile = require('./TutorProfile');
const TutorSubject = require('./TutorSubject');
const Availability = require('./Availability');
const Session = require('./Session');
const Subject = require('./Subject');

User.hasOne(TutorProfile, { foreignKey: 'userId', as: 'tutorProfile', onDelete: 'CASCADE' });
TutorProfile.belongsTo(User, { foreignKey: 'userId', as: 'user' });

TutorProfile.hasMany(TutorSubject, { foreignKey: 'tutorProfileId', as: 'subjects', onDelete: 'CASCADE' });
TutorSubject.belongsTo(TutorProfile, { foreignKey: 'tutorProfileId', as: 'tutorProfile' });

Subject.hasMany(TutorSubject, { foreignKey: 'subjectId', as: 'tutorSubjects' });
TutorSubject.belongsTo(Subject, { foreignKey: 'subjectId', as: 'subject' });

TutorProfile.hasMany(Availability, { foreignKey: 'tutorProfileId', as: 'availability', onDelete: 'CASCADE' });
Availability.belongsTo(TutorProfile, { foreignKey: 'tutorProfileId', as: 'tutorProfile' });

User.hasMany(Session, { foreignKey: 'studentId', as: 'studentSessions' });
User.hasMany(Session, { foreignKey: 'tutorUserId', as: 'tutorSessions' });
Session.belongsTo(User, { foreignKey: 'studentId', as: 'student' });
Session.belongsTo(User, { foreignKey: 'tutorUserId', as: 'tutor' });
Session.belongsTo(Subject, { foreignKey: 'subjectId', as: 'subject' });

module.exports = { sequelize, User, TutorProfile, TutorSubject, Availability, Session, Subject };
