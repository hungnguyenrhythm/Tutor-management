const router = require('express').Router();
const sessionController = require('../controllers/sessionController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

router.post('/', authMiddleware, roleMiddleware('student'), sessionController.createSession);
router.get('/tutor/me', authMiddleware, roleMiddleware('tutor'), sessionController.getTutorSessions);
router.patch('/:id', authMiddleware, sessionController.updateSessionStatus);

module.exports = router;
