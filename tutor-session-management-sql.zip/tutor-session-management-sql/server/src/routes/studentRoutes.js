const router = require('express').Router();
const studentController = require('../controllers/studentController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

router.get('/me/sessions', authMiddleware, roleMiddleware('student'), studentController.getStudentSessions);

module.exports = router;
