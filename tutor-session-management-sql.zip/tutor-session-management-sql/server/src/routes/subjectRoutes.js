const router = require('express').Router();
const subjectController = require('../controllers/subjectController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/', subjectController.getSubjects);
router.post('/', authMiddleware, subjectController.createSubject);
router.post('/seed', authMiddleware, subjectController.seedDefaultSubjects);

module.exports = router;
