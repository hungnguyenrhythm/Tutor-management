const router = require('express').Router();
const tutorController = require('../controllers/tutorController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

router.get('/search', tutorController.searchTutors);
router.get('/me/profile', authMiddleware, roleMiddleware('tutor'), tutorController.getTutorProfile);
router.put('/me/profile', authMiddleware, roleMiddleware('tutor'), tutorController.updateTutorProfile);
router.post('/me/subjects', authMiddleware, roleMiddleware('tutor'), tutorController.addTutorSubject);
router.delete('/me/subjects/:id', authMiddleware, roleMiddleware('tutor'), tutorController.deleteTutorSubject);
router.post('/me/availability', authMiddleware, roleMiddleware('tutor'), tutorController.addAvailability);
router.delete('/me/availability/:id', authMiddleware, roleMiddleware('tutor'), tutorController.deleteAvailability);
router.get('/me/daily-sessions', authMiddleware, roleMiddleware('tutor'), tutorController.getTutorDailySessions);

module.exports = router;
