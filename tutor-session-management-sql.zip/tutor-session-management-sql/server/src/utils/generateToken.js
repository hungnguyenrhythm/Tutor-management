const jwt = require('jsonwebtoken');

module.exports = (user) => jwt.sign(
  { id: user.id, role: user.role, email: user.email },
  process.env.JWT_SECRET,
  { expiresIn: '7d' }
);
